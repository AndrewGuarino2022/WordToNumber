﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Guarino.Capstone_NumberToWordsConvert
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public String Ones(char num)
        {
            String number_value = null;

            switch (num)
            {
                case '1':
                    number_value = "One";
                    break;
                case '2':
                    number_value = "Two";
                    break;
                case '3':
                    number_value = "Three";
                    break;
                case '4':
                    number_value = "Four";
                    break;
                case '5':
                    number_value = "Five";
                    break;
                case '6':
                    number_value = "Six";
                    break;
                case '7':
                    number_value = "Seven";
                    break;
                case '8':
                    number_value = "Eight";
                    break;
                case '9':
                    number_value = "Nine";
                    break;
            }
            return number_value;
        }
        public String Tens(String num)
        {
            int tensChar = 1;//assumes 3 chars in num
            if (num.Length == 2)
                tensChar = 0;

            String number_value = null;

            switch (num[tensChar])
            {
                case '1':
                    {
                        int onesChar = 2;
                        if (num.Length == 2)
                            onesChar = 1;
                        else if (num.Length == 1)
                            onesChar = 0;
                        switch (num[onesChar])
                        {
                            case '0':
                                number_value = "Ten";
                                break;
                            case '1':
                                number_value = "Eleven";
                                break;
                            case '2':
                                number_value = "Twelve";
                                break;
                            case '3':
                                number_value = "Thirteen";
                                break;
                            case '4':
                                number_value = "Fourteen";
                                break;
                            case '5':
                                number_value = "Fifteen";
                                break;
                            case '6':
                                number_value = "Sixteen";
                                break;
                            case '7':
                                number_value = "Seventeen";
                                break;
                            case '8':
                                number_value = "Eighteen";
                                break;
                            case '9':
                                number_value = "Nineteen";
                                break;

                        }
                        return number_value;
                    }
                case '2':
                    number_value = "Twenty";
                    break;
                case '3':
                    number_value = "Thirty";
                    break;
                case '4':
                    number_value = "Fourty";
                    break;
                case '5':
                    number_value = "Fifty";
                    break;
                case '6':
                    number_value = "Sixty";
                    break;
                case '7':
                    number_value = "Seventy";
                    break;
                case '8':
                    number_value = "Eighty";
                    break;
                case '9':
                    number_value = "Ninety";
                    break;
            }
            return number_value;
        }

        public String ThousandsAndGreater(String num)
        {
            int thousandsAndGreaterChar = 4;
            if (num.Length == 4)
                thousandsAndGreaterChar = 0;

            String number_value = null;
            switch (num[thousandsAndGreaterChar])
            {
                case '1':
                    {
                        int onesChar = 2;
                        if (textBox1.Text.Length == 2)
                            onesChar = 1;
                        else if (textBox1.Text.Length == 1)
                            onesChar = 0;
                        switch (num[onesChar])
                        {
                            case '0':
                                number_value = " ";
                                break;
                            case '1':
                                number_value = "Million";
                                break;
                            case '2':
                                number_value = "Billion";
                                break;
                        }
                    }
                    break;

            }
            return number_value;
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            textBox2.Text = "";

            CreateBillionsMillionsThousandsHundredsCentsStrings breakIntoPieces =
                new CreateBillionsMillionsThousandsHundredsCentsStrings(textBox1.Text);

            String[] thePieces = breakIntoPieces.getInputBrokenIntoPieces();

            for (int n = 0; n < thePieces.Length; n++)
            {
                //find hundreds character
                if (thePieces[n].Length == 3)
                    textBox2.Text += Ones(thePieces[n][0]) + " Hundred ";

                //find tens and teens char
                if (thePieces[n].Length > 1)
                    textBox2.Text += Tens(thePieces[n]) + " ";

                //find ones char if it is not a teen
                int tensChar = 1;
                if (thePieces[n].Length == 2)
                    tensChar = 0;
                if (thePieces[n].Length == 1 || thePieces[n][tensChar] != '1')
                {
                    int onesChar = 2;
                    if (thePieces[n].Length == 2)
                        onesChar = 1;
                    else if (thePieces[n].Length == 1)
                        onesChar = 0;

                    textBox2.Text += Ones(thePieces[n][onesChar]);
                }

                if (thePieces[n] != null)
                {
                    switch (n)
                    {
                        case 0:
                            textBox2.Text += " Billion ";
                            break;
                        case 1:
                            textBox2.Text += " Million ";
                            break;
                        case 2:
                            textBox2.Text += " Thousand ";
                            break;
                        case 3:
                            textBox2.Text += " Dollars ";
                            break;
                        case 4:
                            textBox2.Text += " Cents ";
                            break;
                    }
                }
               
            }
        }
    }
}






