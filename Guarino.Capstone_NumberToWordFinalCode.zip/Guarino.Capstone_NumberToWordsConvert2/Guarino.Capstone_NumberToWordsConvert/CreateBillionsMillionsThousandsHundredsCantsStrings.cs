﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Guarino.Capstone_NumberToWordsConvert
{
    class CreateBillionsMillionsThousandsHundredsCentsStrings
    {
        private String[] inputBrokenIntoPieces;
        //inputBrokenIntoPieces[0] = billions
        //inputBrokenIntoPieces[1] = millions
        //inputBrokenIntoPieces[2] = thousands
        //inputBrokenIntoPieces[3] = hundreds
        //inputBrokenIntoPieces[4] = cents

        public CreateBillionsMillionsThousandsHundredsCentsStrings(String originalInput)
        {
            String workingString;

             if(isBadInput(originalInput))
                return;

           workingString = originalInput;
            inputBrokenIntoPieces = new string[5];

            workingString = findCents(workingString);

            if (workingString.Length > 9)
                workingString = findBillions(workingString);

            if (workingString.Length > 6)
                workingString = findMillions(workingString);

            if (workingString.Length > 3)
                workingString = findThousands(workingString);

            if (workingString.Length > 0)
                workingString = findHundreds(workingString);
        }

        private bool isBadInput(string originalInput)
        {
            //remove bad inputs
            if (!onlyOneDecimal(originalInput))
                return true;

            if (!notTooManyChars(originalInput))
                return true;

            return false;
        }

        private bool notTooManyChars(string originalInput)
        {
            string workingString = originalInput;
            const int maxNumberOfCharsToLeftOfDP = 12;
            const int maxNumberOfCharsToRightOfDP = 2;

            if (workingString.Contains("."))
            {
                workingString = originalInput.Substring(originalInput.IndexOf(".") + 1);

                if (workingString.Length > maxNumberOfCharsToRightOfDP)
                {
                    inputBrokenIntoPieces = null;
                    return false;
                }

                workingString = originalInput.Substring(0, originalInput.IndexOf("."));
            }

            if (workingString.Length > maxNumberOfCharsToLeftOfDP)
            {
                inputBrokenIntoPieces = null;
                return false;
            }

            return true;
        }

        private bool onlyOneDecimal(string originalInput)
        {
            if (originalInput.LastIndexOf(".") != originalInput.IndexOf("."))//makes sure only one decimal point
            {
                inputBrokenIntoPieces = null;
                return false;
            }

            return true;
        }

        public String[] getInputBrokenIntoPieces()
        {
            return inputBrokenIntoPieces;
        }

        private String findHundreds(String workingString)
        {
            if (workingString.Length < 3)
            {
                if (workingString.Length == 2)
                {
                    inputBrokenIntoPieces[3] = workingString.Substring(0, 2);
                    return workingString.Substring(2);
                }
                else//Length == 1
                {
                    inputBrokenIntoPieces[3] = workingString.Substring(0, 1);
                    return workingString.Substring(1);
                }
            }
            else//Length == 3
            {
                inputBrokenIntoPieces[3] = workingString.Substring(0, 3);
                return workingString.Substring(3);
            }
        }

        private String findThousands(String workingString)
        {
            if (workingString.Length < 6)
            {
                if (workingString.Length == 5)
                {
                    inputBrokenIntoPieces[2] = workingString.Substring(0, 2);
                    return workingString.Substring(2);
                }
                else//Length == 4
                {
                    inputBrokenIntoPieces[2] = workingString.Substring(0, 1);
                    return workingString.Substring(1);
                }
            }
            else//Length == 6
            {
                inputBrokenIntoPieces[2] = workingString.Substring(0, 3);
                return workingString.Substring(3);
            }
        }

        private String findMillions(String workingString)
        {
            if (workingString.Length < 9)
            {
                if (workingString.Length == 8)
                {
                    inputBrokenIntoPieces[1] = workingString.Substring(0, 2);
                    return workingString.Substring(2);
                }
                else//Length == 7
                {
                    inputBrokenIntoPieces[1] = workingString.Substring(0, 1);
                    return workingString.Substring(1);
                }
            }
            else//Length == 9
            {
                inputBrokenIntoPieces[1] = workingString.Substring(0, 3);
                return workingString.Substring(3);
            }
        }

        private String findBillions(String workingString)
        {
            if (workingString.Length < 12)
            {
                if (workingString.Length == 11)
                {
                    inputBrokenIntoPieces[0] = workingString.Substring(0, 2);
                    return workingString.Substring(2);
                }
                else//Length == 10
                {
                    inputBrokenIntoPieces[0] = workingString.Substring(0, 1);
                    return workingString.Substring(1);
                }
            }
            else//Length == 12
            {
                inputBrokenIntoPieces[0] = workingString.Substring(0, 3);
                return workingString.Substring(3);
            }
        }

        private String findCents(string workingString)
        {
            if (!workingString.Contains("."))
                workingString += ".";//if a decimal point is not input, add one

            int decimalPoint = workingString.IndexOf(".");

            while (workingString.Substring(decimalPoint).Length != 3)
                workingString = workingString + "0";

            inputBrokenIntoPieces[4] = workingString.Substring(decimalPoint + 1);

            return workingString.Substring(0, decimalPoint);
        }
    }
}
