﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Guarino.Capstone_NumbersToWords_Code
{
    public class moneyToWordsConvert
    {
    }
}