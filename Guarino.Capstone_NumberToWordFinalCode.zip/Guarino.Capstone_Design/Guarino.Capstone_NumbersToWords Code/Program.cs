﻿using System;

namespace Guarino.Capstone_NumbersToWords_Code
{
    class Program
    {
        static void Main(string[] args)
        {
           
        }
    }
}
