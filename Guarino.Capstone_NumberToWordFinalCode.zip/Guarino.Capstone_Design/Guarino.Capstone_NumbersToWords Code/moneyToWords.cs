﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Guarino.Capstone_NumbersToWords_Code
{
    class moneyToWords

    {
        //take user input through textbox created within windows application
        //allow input to only by postive and 1 through billion
        //with data inputted through textbox allow that text box be named txtUserMoenyToWordsConversion

        public String conversionOfOnes(String onesDigits)
        {
            //convert digits 1 - 9  to words (one, two, three, four, etc.)
        }

        public String conversionOfTens (String tensDigits)
        {
            //convert digits 10 - 19 to words (ten, eleven, twevle, thirteen, fourteen, etc.)
            //10 - 19 are stand alone words
            //every tens digits needs a ones number (13 convert to thirteen)
        }

        public String converionOfCents (String centsDigits)
        {
            //allow user to input period before number
            //limit user to two decimal points (.55) anything less or more can result in invalid number
            //allow user to input 01 - 99 as the cents
            //negatices are not allowed
        }

        public String conversionOfEntireNumber (String onesDigits, String tensDigits, String centsDigits)
        {
            //take user input from textbox
            //hundred to every number input that has  three digits 
            //thousand to every number inputed that has four digits
            //million to every number inputted that has 7 digits
            //billion to every number inputted that has 10 digits
            //no number over billon
            //no numner to be negative resulting in invalid number 
        }
    }

   
}
